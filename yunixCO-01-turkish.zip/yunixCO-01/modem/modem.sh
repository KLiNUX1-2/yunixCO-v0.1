#!/data/data/com.termux/files/usr/bin/bash

MODEM_IP="192.168.1.1"
MODEM_SCHEME="https"

while true; do
    MODEM_URL="$MODEM_SCHEME://$MODEM_IP/"

    clear
    echo "================================"
    echo "    YUNIX CO MODEM SOFTWARE"
    echo "================================"
    echo "Modem adresi: $MODEM_IP"
    echo
    echo "1. Modem adresini kontrol et"
    echo "2. İnternet bağlantısını test et"
    echo "3. Modem yönetim panelini aç"
    echo "4. Modem SSL sertifikasını göster"
    echo "5. Address Changing Mode"
    echo "0. Ana menüye dön"
    echo

    read -r -p "Seçiminiz: " secim

    case "$secim" in
        1)
            echo
            if curl -k -sS -I --max-time 5 "$MODEM_URL"; then
                echo
                echo "Modem web sunucusundan yanıt alındı."
            else
                echo "Modeme ulaşılamadı."
            fi
            read -r -p "Devam etmek için Enter..."
            ;;
        2)
            echo
            if curl -sS -L --max-time 8 \
                -o /dev/null \
                -w "HTTP kodu: %{http_code}\n" \
                https://example.com; then
                echo "İnternet isteği tamamlandı."
            else
                echo "İnternet bağlantısı test edilemedi."
            fi
            read -r -p "Devam etmek için Enter..."
            ;;
        3)
            am start -a android.intent.action.VIEW -d "$MODEM_URL"
            read -r -p "Devam etmek için Enter..."
            ;;
        4)
            echo
            echo "Sertifika bilgileri:"
            if command -v openssl >/dev/null 2>&1; then
                timeout 8 openssl s_client \
                    -connect "$MODEM_IP:443" \
                    -servername "$MODEM_IP" \
                    </dev/null 2>/dev/null |
                openssl x509 -noout \
                    -subject -issuer -dates -fingerprint -sha256
            else
                echo "OpenSSL kurulu değil. Kurmak için: pkg install openssl"
            fi
            read -r -p "Devam etmek için Enter..."
            ;;
        5)
            while true; do
                clear
                echo "================================"
                echo " ADDRESS CHANGE KANAL LISTESI"
                echo "================================"
                echo "Aktif adres: $MODEM_IP"
                echo
                echo "1. 192.168.1.1 (TURKIYE 1)"
                echo "2. 192.168.0.1 (TURKIYE 2)"
                echo "3. 192.168.2.1 (TURKIYE 3)"
                echo "4. 10.0.0.1 (AMERIKA 1)"
                echo "0. Geri dön"
                echo

                read -r -p "Adres seçimi: " adres_secim

                case "$adres_secim" in
                    1)
                        MODEM_IP="192.168.1.1"
                        echo "Adres seçildi: $MODEM_IP MARKA:TURKIYE_POPULER"
                        break
                        ;;
                    2)
                        MODEM_IP="192.168.0.1"
                        echo "Adres seçildi: $MODEM_IP MARKA: TURKIYE_2 "
                        break
                        ;;
                    3)
                        MODEM_IP="192.168.2.1"
                        echo "Adres seçildi: $MODEM_IP MARKA: TURKIYE_3"
                        break
                        ;;

                    4)
                        MODEM_IP="10.0.0.1"
                        echo "Adres seçildi: $MODEM_IP MARKA: COMCAST "
                        break
                        ;;

                    0)
                        break
                        ;;
                    *)
                        echo "Geçersiz seçim!"
                        sleep 1
                        ;;
                esac
            done
            ;;
        0)
            exit 0
            ;;
        *)
            echo "Geçersiz seçim!"
            sleep 1
            ;;
    esac
done