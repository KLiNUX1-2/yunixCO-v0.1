<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

const DEFAULT_MODEM_IP = '192.168.1.1';
const MODEM_SCHEME = 'https';

$modemIp = DEFAULT_MODEM_IP;

function phpError(string $type, string $message, int $code): void
{
    echo "\n";
    echo "================================\n";
    echo "       YUNIX CO PHP ERROR\n";
    echo "================================\n";
    echo "PHP {$type}: {$message}\n";
    echo "Error Code: {$code}\n";
    echo "================================\n";
}

function pauseScreen(): void
{
    echo "\nDevam etmek için Enter...";
    fgets(STDIN);
}

function runCommand(array $command, int $timeout = 8): array
{
    $process = proc_open(
        $command,
        [
            0 => ['file', '/dev/null', 'r'],
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w'],
        ],
        $pipes
    );

    if (!is_resource($process)) {
        return [false, '', 'İşlem başlatılamadı.'];
    }

    stream_set_blocking($pipes[1], false);
    stream_set_blocking($pipes[2], false);

    $stdout = '';
    $stderr = '';
    $start = time();
    $timedOut = false;

    while (true) {
        $stdout .= stream_get_contents($pipes[1]);
        $stderr .= stream_get_contents($pipes[2]);

        $status = proc_get_status($process);

        if (!$status['running']) {
            break;
        }

        if (time() - $start >= $timeout) {
            proc_terminate($process);
            $timedOut = true;
            break;
        }

        usleep(100000);
    }

    $stdout .= stream_get_contents($pipes[1]);
    $stderr .= stream_get_contents($pipes[2]);

    fclose($pipes[1]);
    fclose($pipes[2]);

    $exitCode = proc_close($process);

    if ($timedOut) {
        return [false, $stdout, 'İşlem zaman aşımına uğradı.'];
    }

    if ($exitCode !== 0 && $stdout === '') {
        return [false, $stdout, trim($stderr) ?: 'Komut başarısız oldu.'];
    }

    return [true, $stdout, $stderr];
}

function checkModem(string $ip): void
{
    echo "\nModem kontrol ediliyor: {$ip}\n";

    [$ok, $output, $error] = runCommand([
        'curl', '-k', '-sS', '-I',
        '--max-time', '5',
        MODEM_SCHEME . '://' . $ip . '/'
    ], 7);

    if (!$ok) {
        phpError('Warning', 'Modeme ulaşılamadı: ' . $error, 1001);
        return;
    }

    echo $output;
    echo "\nModem web sunucusundan yanıt alındı.\n";
}

function checkInternet(): void
{
    echo "\nİnternet bağlantısı test ediliyor...\n";

    [$ok, $output, $error] = runCommand([
        'curl', '-sS', '-L',
        '--max-time', '8',
        '-o', '/dev/null',
        '-w', 'HTTP kodu: %{http_code}\n',
        'https://example.com'
    ], 10);

    if (!$ok) {
        phpError('Warning', 'İnternet isteği başarısız: ' . $error, 1002);
        return;
    }

    echo $output;
    echo "İstek tamamlandı.\n";
}

function openModem(string $ip): void
{
    $url = MODEM_SCHEME . '://' . $ip . '/';

    [$ok, $output, $error] = runCommand([
        'am', 'start',
        '-a', 'android.intent.action.VIEW',
        '-d', $url
    ], 5);

    if (!$ok) {
        phpError('Warning', 'Tarayıcı açılamadı: ' . $error, 1003);
        return;
    }

    echo "Modem paneli açma isteği gönderildi: {$url}\n";
}

function showCertificate(string $ip): void
{
    echo "\nSSL sertifika bilgileri: {$ip}\n";

    [$ok, $output, $error] = runCommand([
        'openssl', 's_client',
        '-connect', $ip . ':443',
        '-servername', $ip
    ], 5);

    if (!$ok && trim($output) === '') {
        phpError('Warning', 'Sertifika bağlantısı kurulamadı.', 1004);
        return;
    }

    // Sertifika ayrıntılarını ayrı bir komutla al.
    [$certOk, $certOutput, $certError] = runCommand([
        'sh', '-c',
        'openssl s_client -connect "$1:443" -servername "$1" </dev/null 2>/dev/null | openssl x509 -noout -subject -issuer -dates -fingerprint -sha256',
        'sh', $ip
    ], 8);

    if (!$certOk || trim($certOutput) === '') {
        phpError('Warning', 'Sertifika okunamadı: ' . $certError, 1005);
        return;
    }

    echo $certOutput;
}

function chooseAddress(string &$ip): void
{
    while (true) {
        echo "\n";
        echo "================================\n";
        echo " ADDRESS CHANGE KANAL LISTESI\n";
        echo "================================\n";
        echo "Aktif adres: {$ip}\n\n";
        echo "1. 192.168.1.1 (Yaygın yerel adres)\n";
        echo "2. 192.168.0.1 (Alternatif yerel adres)\n";
        echo "3. 192.168.2.1 (Alternatif yerel adres)\n";
        echo "4. 10.0.0.1 (Bazı ağlarda kullanılır)\n";
        echo "0. Geri dön\n\n";
        echo "Adres seçimi: ";

        $choice = trim(fgets(STDIN));

        $addresses = [
            '1' => '192.168.1.1',
            '2' => '192.168.0.1',
            '3' => '192.168.2.1',
            '4' => '10.0.0.1',
        ];

        if ($choice === '0') {
            return;
        }

        if (isset($addresses[$choice])) {
            $ip = $addresses[$choice];
            echo "Hedef adres seçildi: {$ip}\n";
            echo "Not: Bu seçim modem ayarlarını değiştirmez.\n";
            return;
        }

        phpError('Notice', 'Geçersiz adres seçimi.', 2001);
    }
}

while (true) {
    if (function_exists('system')) {
        system('clear');
    }

    echo "================================\n";
    echo "    YUNIX CO MODEM SOFTWARE\n";
    echo "================================\n";
    echo "Modem adresi: {$modemIp}\n\n";
    echo "1. Modem adresini kontrol et\n";
    echo "2. İnternet bağlantısını test et\n";
    echo "3. Modem yönetim panelini aç\n";
    echo "4. Modem SSL sertifikasını göster\n";
    echo "5. Address Changing Mode\n";
    echo "0. Ana menüye dön\n\n";
    echo "Seçiminiz: ";

    $choice = trim(fgets(STDIN));

    switch ($choice) {
        case '1':
            checkModem($modemIp);
            pauseScreen();
            break;

        case '2':
            checkInternet();
            pauseScreen();
            break;

        case '3':
            openModem($modemIp);
            pauseScreen();
            break;

        case '4':
            showCertificate($modemIp);
            pauseScreen();
            break;

        case '5':
            chooseAddress($modemIp);
            break;

        case '0':
            exit(0);

        default:
            phpError('Notice', 'Geçersiz menü seçimi.', 2001);
            sleep(1);
    }
}